function reloadCookies() {
    $("tbody").html("");
    chrome.tabs.getSelected(null, function(e) {
        chrome.cookies.getAll({
            url: e.url
        }, function(t) {
            $(t).each(function(t, n) {
                addItem(n, e.url)
            })
        })
    })
}

function addItem(e, t) {
    $("<tr >" + "<td>" + e.domain + "</td>" + '<td><input type="text" value="' + e.value + '" /></td>' + "<td>" + getDateTime(e.expirationDate) + "</td>" + '<td><button class="btn btn-xs btn-danger" type="button" data-url="' + t + '" data-val="' + e.name + '" >FORGET</button></td>' + "</tr>").appendTo("tbody")
}


function getDateTime(e) {
    if (typeof e == "undefined") return "";
    var t = new Date(e * 1e3);
    var n = t.getHours();
    var r = t.getMinutes();
    var i = t.getSeconds();
    var s = t.getMonth();
    var o = t.getDate();
    var u = t.getFullYear();
    var a = u + "-" + s + "-" + o + " " + n + ":" + r + ":" + i;
    return a
}
$(function() {
    reloadCookies();
    $("table.table").on("click", "button.btn-danger", function() {
        var e = this;
        if (confirm("DO YOU TRULY WANT TO ENGAGE IN THE FACADE OF DATA PRIVACY?")) {
            chrome.cookies.remove({
                name: $(e).attr("data-val"),
                url: $(e).attr("data-url")
            }, function(e) {});
            $(e).closest("tr").remove()
        }
    });
    $("table.table").on("mouseup", "input", function(e) {
        e.preventDefault()
    });
    $("table.table").on("focus", "input", function(e) {
        $(this).select()
    })
})